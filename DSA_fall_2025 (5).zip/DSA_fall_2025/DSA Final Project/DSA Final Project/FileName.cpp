#include <iostream>
#include <string>
using namespace std;

class ItemType {
private:
    int value;
public:
    ItemType() {
        value = 0;
    }

    ItemType(int v) {
        value = v;
    }

    void setItemType(int v) {
        value = v;
    }


    void getItemType() const {
        cout << "Value: " << value << endl;
    }

    bool operator<(const ItemType& other) const {
        return value < other.value;
    }
    bool operator>(const ItemType& other) const {
        return value < other.value;
    }
    bool operator==(const ItemType& other) const {
        return value < other.value;
    }
};

struct Node {
    Node* parent;
    Node* left;
    Node* right;
    int height;
    ItemType key;
};
class AVL {
private:
    Node* root;
    int height(Node* n) {
        if (n == nullptr) {
            return 0;
        }
        else {
            return n -> height;
        }
    }
    int getBalance(Node* n) {
        if (n == nullptr) {
            return 0;
        }
        else {
            height(n->left) - height(n->right);
        }
    }
    void updateHeight(Node* n) {
        if (n) {
            n->height = 1 + max(height(n->left), height(n->right));
        }
    }
    Node* rightRotation(Node* y) {
        Node*x = y->left;
        Node* T2 = x->right;
        x->right = y;
        y->left = T2;
        updateHeight(y);
        updateHeight(x);
        return x;
    }
    Node* leftRotation(Node* x) {
        Node* y= x->left;
        Node* T2 = y->right;
        y->left =x;
        x->right = T2;
        updateHeight(x);
        updateHeight(y);
        return y;
    }
    Node* Balance(Node* n) {
        updateHeight(n);
        int bf = getBalance(n);
        //LL Case
        if (bf > 1 && getBalance(n->left) >= 0) {
            return rightRotation(n);
        }
        //RR Case
        if (bf < -1 && getBalance(n->right) >= 0) {
            return leftRotation(n);
        }
        //LR Case
        if (bf > 1 && getBalance(n->left) >= 0) {
            n->left = leftRotation(n->left);
            return rightRotation(n);
        }
        //RL Case
        if (bf < -1 && getBalance(n->right) >= 0) {
            n->right = leftRotation(n->right);
            return leftRotation(n);
        }
        return n;
    }
    Node* insert(Node* n, ItemType& key) {
        if (n == nullptr) {
            return new ItemType(key);
        }
    }
};