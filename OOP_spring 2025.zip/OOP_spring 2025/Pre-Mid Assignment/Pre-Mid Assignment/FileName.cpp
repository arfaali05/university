                                //TASK #1//
#include<iostream>
#include<string>
using namespace std;
class BankAccount{
private:
	string name;
	int acc_no;
	double balance;
	static int no_of_accounts;
public:
	BankAccount() {
		string name = "";
		int acc_no = 0;
		double balance = 0.0;
	}
	//Constructor
	BankAccount(string n, int a, double b) {
		name = n;
		acc_no = a;
		balance = b;
		no_of_accounts++;
	}
	//Destructor
	~BankAccount() {
		cout << " Account Deleted" << endl;
		no_of_accounts--;
	}
	//Friend Member Function
	friend void transferMoney(BankAccount& from, BankAccount& to, double amount);
	//Static Member function
	static void displaytotalaccounts()
	{
		cout << "Number of Accounts: " << no_of_accounts << endl;
	}
	void displayAccount() const{
		cout << "Account Number: " << acc_no << "\nName: " << name << "\nBank balance:" << balance << endl;
	}
	//Setters & Getters
	void setname(string n) {
		name = n;
	}
	void setacc_no(int a) {
		acc_no = a;
	}
	void setbalance(double newbalance) {
		balance = newbalance;
	}
	string getname()const {
		return name;
	}
	int getacc_no()const {
		return acc_no;
	}
	double getbalance()const {
		return balance;
	}
};
int BankAccount::no_of_accounts = 0;

	void transferMoney(BankAccount& from, BankAccount& to, double amount)
	{
		if (from.balance >= amount)
		{
			from.balance -= amount;
			to.balance += amount;
			cout << "Transferred $" << amount << " from " << from.name << " to " << to.name << ".\n";
		}
		else
		{
			cout << "Insufficient balance in " << from.name << "'s account.\n";
		}
	}


                               //TASK #2//
class Complex {
private:
	double real;
	double img;

public:
	// Constructor
	Complex() {
		real = 0.0;
		img = 0.0;
	}
	Complex(double r, double i) {
		real = r;
		img = i;
	}
	// Overloading Arithmetic Operators
	Complex operator+(const Complex& c) const 
	{ return { real + c.real, img + c.img }; }
	Complex operator-(const Complex& c) const 
	{ return { real - c.real, img - c.img }; }
	Complex operator*(const Complex& c) const 
	{ return { real * c.real - img * c.img, real * c.img + img * c.real }; }
	Complex operator/(const Complex& c) const 
	{
		double denom = c.real * c.real + c.img * c.img;
		return { (real * c.real + img * c.img) / denom, (img * c.real - real * c.img) / denom };
	}

	// Overloading Stream Operators
	friend istream& operator>>(istream& in, Complex& c) {
		cout << "Enter real and imaginary parts: ";
		return in >> c.real >> c.img;
	}
	friend ostream& operator<<(ostream& out, const Complex& c) {
		return out << c.real << " + " << c.img << "i";
	}

	// Overloading Function Call Operator (Returns Magnitude)
	double magnitude() const
	{
		return sqrt(real * real + img * img);
	}
	double operator()() const
	{
		return magnitude();
	}

	bool operator==(const Complex& c)
	{
		return real == c.real && img == c.img;
	}
	bool operator!=(const Complex& c)
	{
		return !(*this == c);
	}
	bool operator<(const Complex& c)
	{
		return magnitude() < c.magnitude();
	}
	bool operator>(const Complex& c)
	{
		return magnitude() > c.magnitude();
	}
	bool operator<=(const Complex& c)
	{
		return magnitude() <= c.magnitude();
	}
	bool operator>=(const Complex& c)
	{
		return magnitude() >= c.magnitude();
	}

	// Overloading Compound Assignment Operators
	Complex& operator+=(const Complex& c)
	{
		real += c.real;
		img += c.img;
		return *this;
	}
	Complex& operator-=(const Complex& c)
	{
		real -= c.real;
		img -= c.img;
		return *this;
	}
	Complex& operator*=(const Complex& c)
	{
		*this = *this * c;
		return *this;
	}
	Complex& operator/=(const Complex& c)
	{
		*this = *this / c;
		return *this;
	}

	// Overloading Subscript Operator (Accessing real and imaginary parts)
	double operator[](int index)
	{
		if (index == 0)
			return real;
		else if (index == 1)
			return img;
		else {
			cout << "Invalid index!";
			return 0;
		}
	}

};
                                 //TASK #3//
class Student {
private:
	int ID;
	string name;
	double gpa;
	static int totalStudent;
public:
	//Constructor
	Student(int i, string n, double g) {
		ID = i;
		name = n;
		gpa = g;
		totalStudent++;
	}
	//Setters & Getters
	void setname(string n) {
		name = n;
	}
	void setID(int i) {
		ID = i;
	}
	void setGPA(double newGPA) {
		gpa = newGPA;
	}
	int getId() const {
		return ID;
	}
	string getName() const {
		return name;
	}
	double getGPA() const {
		return gpa;
	}

	// Static Member Function 
	static void displayTotalStudent() {
		cout << "Total students: " << totalStudent << endl;
	}

	// Display Member Function
	void displayStudentDetails() const {
		cout << "ID: " << ID << endl;
		cout << "Name: " << name << endl;
		cout << "GPA: " << gpa << endl;
	}
	//UML Diagram
	void displayDetails() {
		cout << "\n+----------------+" << endl;
		cout << "|    Student    |" << endl;
		cout << "+----------------+" << endl;
		cout << "| ID: " << ID << "      |" << endl;
		cout << "| Name: " << name << "  |" << endl;
		cout << "| GPA: " << gpa << "      |" << endl;
		cout << "+----------------+" << endl;
	}
	//Update GPA
	static void updateGPA(Student students[], int size, int id, double newGPA)
	{
		for (int i = 0; i < size; i++) {
			if (students[i].ID == id) {
				students[i].setGPA(newGPA);
				cout << "GPA updated for student ID: " << id << endl;
				students[i].displayDetails();
				return;
			}
		}
	}
};
	int Student:: totalStudent;

                               //MAIN PROGRAM//
int main() {
	int choice;
	cout << "Select a program to run:\n";
	cout << "1. Bank Account Management System\n";
	cout << "2. Complex Number Calculator\n";
	cout << "3. Student Record System\n";
	cout << "Enter your choice: ";
	cin >> choice;

	switch (choice) {
	case 1:
	{
		int n;
		cout << "Enter number of bank accounts: ";
		cin >> n;

		BankAccount* accounts = new BankAccount[n];

		for (int i = 0; i < n; i++) {
			string Name;
			int acc_no;
			double balance;

			cout << "Enter details for account " << i + 1 << ":\n";
			cout << "Enter Name: ";
			cin.ignore();
			getline(cin, Name);
			cout << "Enter Account Number: ";
			cin >> acc_no;
			cout << "Enter Initial Balance: ";
			cin >> balance;

			accounts[i].setname(Name);
			accounts[i].setacc_no(acc_no);
			accounts[i].setbalance(balance);
		}

		cout << "Initial Account Details:" << endl;
		for (int i = 0; i < n; i++) {
			cout << "Account " << i + 1 << " - Name: " << accounts[i].getname()
				<< ", Balance: $" << accounts[i].getbalance() << endl;
		}

		cout << "Money Transfer: " << endl;
		if (n >= 2) transferMoney(accounts[0], accounts[1], 100);
		if (n >= 3) transferMoney(accounts[1], accounts[2], 103);
		if (n >= 4) transferMoney(accounts[2], accounts[3], 800);

		cout << "Final Account Balances:" << endl;
		for (int i = 0; i < n; i++) {
			cout << "Account " << i + 1 << " - Name: " << accounts[i].getname()
				<< ", Balance: $" << accounts[i].getbalance() << endl;
		}

		BankAccount::displaytotalaccounts();

		delete[] accounts;
		break;
	
	}
	case 2: 
	{
		Complex c1, c2;

		cout << "Enter the first complex number: ";
		cin >> c1;

		cout << "Enter the second complex number: ";
		cin >> c2;

		cout << "c1: " << c1 << ", c2: " << c2 << endl;

		// Arithmetic operations
		cout << "Addition: " << c1 + c2 << endl;
		cout << "Subtraction: " << c1 - c2 << endl;
		cout << "Multiplication: " << c1 * c2 << endl;
		cout << "Division: " << c1 / c2 << endl;

		// Compound assignment operations
		c1 += c2;
		cout << "After c1 += c2: " << c1 << endl;

		// Relational operator examples
		cout << "c1 > c2: " << (c1 > c2) << endl;
		cout << "c1 < c2: " << (c1 < c2) << endl;

		// Subscript operator
		cout << "Real part of c1: " << c1[0] << ", Imaginary part of c1: " << c1[1] << endl;

		// Function call operator
		cout << "Magnitude of c1: " << c1() << endl;
		break;
	}
	case 3:
	{
	Student students[3] = { Student(0, "", 0.0), Student(0, "", 0.0), Student(0, "", 0.0) };

		for (int i = 0; i < 3; i++)
		{
			int id;
			string name;
			float gpa;

			cout << "Enter details for Student " << i + 1 << ":" << endl;
			cout << "Student ID: ";
			cin >> id;
			students[i].setID(id);
			cout << "Name: ";
			cin >> name;
			students[i].setname(name);
			cout << "GPA: ";
			cin >> gpa;
			students[i].setGPA(gpa);

			students[i].getId();
			students[i].getName();
			students[i].getGPA();
		}
		// Display total number of students
		Student::displayTotalStudent();
		//UML Representation
	    const int numStd = 3;
		cout << "Student Records (UML diagram) :\n";
		for (int i = 0; i < numStd; i++) {
			students[i].displayDetails();
		}

		//New GPA of a student
		int searchID;
		float newGPA;
		cout << "Enter Student ID to update the GPA: ";
		cin >> searchID;
		cout << "Enter new GPA: ";
		cin >> newGPA;

		//Static function call for updated GPA
		Student::updateGPA(students, 3, searchID, newGPA);
		break;
	}

	default:
		cout << "Invalid choice! Please select 1, 2, or 3.\n";
	}
	return 0;
	                         // THE END :) //
}                       




