CREATE DATABASE RetailDB;
USE RetailDB;

CREATE TABLE Customers
(customer_id INT PRIMARY KEY UNIQUE NOT NULL AUTO_INCREMENT, 
customer_name VARCHAR(50) NOT NULL,
email VARCHAR(100) UNIQUE NOT NULL CHECK (email LIKE '%_@_%.%_'),
city VARCHAR(50) NULL,
gender CHAR(1) NULL,
registration_date DATE NOT NULL DEFAULT(CURDATE())
);

INSERT INTO Customers(customer_name,email,city,gender,registration_date)VALUES
('Arfa Ali','arfa07@gmail.com','Lahore','F','2026-01-09'),
('Ali Akbar','ali01@gmail.com','Karachi','M','2026-02-19'),
('Aaliyan Ali','aali7@gmail.com','Tokyo','M','2026-03-07'),
('Hamza Yousaf','hamza13@gmail.com','Lahore','M','2026-09-13'),
('Hiba Khan','hiba09@gmail.com','London','F','2026-09-09'),
('Tayyaba Farooq','tabi07@gmail.com','Istanbul','F','2026-04-07'),
('Ayesha Javaid','ashi15@gmail.com','California','F','2026-10-15'),
('Afzal Asim','fazlu11@gmail.com','New York','M','2026-08-09'),
('Saleha Masood','salala@gmail.com','Sargodha','F','2026-01-01'),
('Sameer Ali','sam7@gmail.com','Islamabad','M','2026-01-09'),
('Rabbiya Ali','rabi05@gmail.com','Lahore','F','2026-07-05'),
('Ali Tayyab','tayyab25@gmail.com','Berlin','M','2026-07-25'),
('Haneen Yousaf','hahaha@gmail.com','Jeddah','F','2026-01-01'),
('Rabia Muhammad','rarara@gmail.com','Dammam','F','2026-08-20'),
('Hamna Asghar','hamna17@gmail.com','Kabul','F','2026-11-17');

CREATE TABLE Products
(product_id INT PRIMARY KEY NOT NULL,
product_name VARCHAR(50) NOT NULL,
category VARCHAR(50) NOT NULL,
price FLOAT NOT NULL CHECK(price >=0),
stock_quantity INT NOT NULL DEFAULT 0 CHECK(stock_quantity>=0),
is_active BOOLEAN DEFAULT TRUE
);

INSERT INTO Products(product_id,product_name,category,price,stock_quantity,is_active)VALUES
(1,'Frying Pan','Kitchen',1550.0,10,TRUE),
(2,'Washing Machine','Electronics',105000.0,13,TRUE),
(3,'Bed Set','Furniture',205000.0,0,FALSE),
(4,'Smartphones','Technology',300020.0,50,TRUE),
(5,'Blankets','Home',20000.0,0,FALSE),
(6,'Cereal','Grocery',500.0,30,TRUE),
(7,'Jacket','Clothes',15000.0,0,FALSE),
(8,'Shampoo','Essentials',1000.9,55,TRUE),
(9,'Toaster','Electronics',12000.0,43,TRUE),
(10,'Plates & Bowls','Kitchen',1500.0,0,FALSE),
(11,'Laptops','Technology',200004.0,22,TRUE),
(12,'Body Lotion','Essentials',2000.0,0,FALSE),
(13,'Cooking Oil','Grocery',300.6,13,TRUE),
(14,'Bedsheets','Home',3000.8,0,FALSE),
(15,'Dining Table','Furniture',300040.9,22,TRUE);

CREATE TABLE Sales
(sale_id INT PRIMARY KEY NOT NULL,
customer_id INT NOT NULL,
FOREIGN KEY(customer_id) REFERENCES Customers(customer_id),
product_id INT NOT NULL,
FOREIGN KEY(product_id) REFERENCES Products(product_id),
quantity INT NOT NULL CHECK(quantity>=0),
sale_date DATE NOT NULL DEFAULT(CURDATE())
);
INSERT INTO Sales(sale_id,customer_id,product_id,quantity,sale_date)VALUES
(101,1,2,23,'2026-01-11'),(102,2,1,15,'2026-11-21'),(103,3,4,33,'2026-09-30'),
(104,4,6,22,'2026-10-11'),(105,5,9,43,'2026-11-13'),(106,6,8,56,'2026-01-02'),
(107,7,11,47,'2026-02-22'),(108,8,6,12,'2026-04-24'),(109,9,13,10,'2026-07-02'),
(110,10,4,17,'2026-08-16'),(111,11,15,11,'2026-12-28'),(112,12,2,35,'2026-06-26'),
(113,13,1,33,'2026-11-09'),(114,14,9,44,'2026-10-10'),(115,15,11,20,'2026-12-28');

CREATE TABLE Suppliers
(supplier_id INT PRIMARY KEY NOT NULL,
supplier_name VARCHAR(50) NOT NULL,
contact_email VARCHAR(100) UNIQUE,
city VARCHAR(50) NULL,
phone_number VARCHAR(50) NULL,
registration_date DATE NOT NULL DEFAULT(CURDATE())
);

INSERT INTO Suppliers(supplier_id,supplier_name,contact_email,city,phone_number,registration_date)VALUES
(1,'Ahmad Ali','ahmad@gmail.com','Lahore','0300-4995695','2026-01-11'),
(2,'Babar Azam','babar@gmail.com','Karachi','0300-4995234','2026-11-22'),
(3,'Daud Irfan','daud@gmail.com','Lahore','0302-4925695','2026-03-04'),
(4,'Daniyal Arif','dani@gmail.com','Islamabad','0310-2343695','2026-09-21'),
(5,'Asim Munir','asim@gmail.com','Quetta','0300-43456645','2026-06-12'),
(6,'Subhan Khan','khan@gmail.com','Lahore','0300-49234545','2026-01-22'),
(7,'Nadeem Ahsan','nadeem@gmail.com','Lahore','0334-4995645','2026-12-31'),
(8,'Sultan Qasim','sultan@gmail.com','Okara','0321-4564324','2026-07-30'),
(9,'Abdullah Khan','abdul@gmail.com','Karachi','0300-33445566','2026-04-17'),
(10,'Salman Khan','salman@gmail.com','Islamabad','0300-22331155','2026-05-14'),
(11,'Zeeshan Waqar','zeesha@gmail.com','Multan','0300-4564334','2026-08-22'),
(12,'Yahya Syed','yahya@gmail.com','Hyderabad','0300-49955345','2026-03-12'),
(13,'Iqbal Cheema','iqbal@gmail.com','Murree','0300-49937985','2026-09-24'),
(14,'Gohar Shareef','gohar@gmail.com','Gujranwala','0300-34345695','2026-07-07'),
(15,'Bilal Ikram','bilal@gmail.com','Multan','0300-4537876','2026-12-31');
-- Q1 --
SELECT DISTINCT city,gender FROM Customers  Order by city ASC, gender ASC;
-- Q2 --
SELECT product_name, price, price*0.9 AS Discounted_Price FROM Products 
WHERE is_active=TRUE AND price>1000 ORDER BY price DESC;
-- Q3 --
SELECT quantity, sale_date, DATE_FORMAT(sale_date,'%W-%D-%M-%Y') AS date_and_day FROM sales 
WHERE quantity>1 AND DAYNAME(sale_date)IN('Monday','Tuesday' ,'Wednesday')
ORDER BY sale_date DESC, quantity ASC;
-- Q4 --
SELECT category, Count(product_name)As total_products,count(stock_quantity) AS total_stock 
FROM Products GROUP BY category ORDER BY total_products DESC;
-- Q5 --
SELECT category, AVG(price),MAX(price) FROM Products
GROUP BY category HAVING AVG(price)>1000 ORDER BY AVG(price) DESC;
-- Q6 --
SELECT customer_id ,SUM(quantity) AS total_quantity,Count(sale_id) As total_orders 
FROM Sales WHERE quantity>0 GROUP BY customer_id ORDER BY total_quantity DESC;
-- Q7 --
SELECT category, MAX(price) AS max_price,MIN(price) AS min_price,AVG(price) AS avg_price 
FROM Products GROUP BY category HAVING MIN(price)<5000 ORDER BY avg_price DESC;
-- Q8 --
SELECT DISTINCT(customer_id),product_id,SUM(quantity) AS total_sales 
FROM Sales GROUP BY customer_id,product_id HAVING(total_sales)>2 ORDER BY total_sales DESC;
-- Q9 --
SELECT product_id, SUM(quantity) as total_units,AVG(quantity) AS avg_quantity 
FROM Sales GROUP BY product_id HAVING(total_units)>1 ORDER BY total_units DESC,avg_quantity ASC;
-- Q10 --
SELECT *, quantity>1 AND sale_date between '2026-01-01'AND '2026-03-01'AND MOD(sale_id,2)=0 AS all_sales
FROM Sales ORDER BY sale_date DESC,quantity ASC;
-- Q11 --
SELECT category,SUM(stock_quantity) AS total_stock, COUNT(product_name) AS Total_products 
FROM Products GROUP BY category HAVING SUM(stock_quantity)>20 ORDER BY total_stock DESC;
-- Q12 --
SELECT CONCAT(UPPER(LEFT(customer_name, 1)), LOWER(SUBSTRING(customer_name, 2))) AS formatted_name,
DATE_FORMAT(registration_date, '%M-%Y') AS formatted_date FROM Customers WHERE registration_date < CURDATE()
ORDER BY registration_date DESC;