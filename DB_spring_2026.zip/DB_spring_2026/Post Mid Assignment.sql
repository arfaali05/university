Use FinanceLab;


-- CTE 1: Get transaction totals per account
WITH trans_totals AS (
    SELECT
        account_id,
        COUNT(transaction_id) AS total_trans,
        SUM(CASE WHEN transaction_type = 'Deposit'THEN amount ELSE 0 END) AS total_deposits,
        SUM(CASE WHEN transaction_type = 'Withdrawal'THEN amount ELSE 0 END) AS total_withdrawals
    FROM Transactions
    GROUP BY account_id
),

-- CTE 2: Build full account profile using JOINs
account_profile AS (
    SELECT
        c.customer_id,
        c.customer_name,
        c.city,
        c.segment,
        IFNULL(a.account_id,'No Account') AS account_id,
        IFNULL(a.account_type,'No Account') AS account_type,
        IFNULL(a.opening_balance, 0) AS opening_balance,
        IFNULL(a.open_date,'No Date') AS open_date,

        IFNULL(t1.total_trans,0) AS total_trans,
        IFNULL(t1.total_deposits,0)AS total_deposits,
        IFNULL(t1.total_withdrawals,0)AS total_withdrawals,
        IFNULL(t1.total_deposits,0)-IFNULL(t1.total_withdrawals, 0) AS net_flow,

        CASE
            WHEN a.open_date IS NULL THEN 0
            ELSE DATEDIFF(a.open_date, c.registration_date)
        END AS days_to_open,

        -- Suspicion score using nested CASE WHEN
        CASE
            WHEN a.account_id IS NULL
                THEN 40
            WHEN IFNULL(t1.total_trans, 0) = 0 AND IFNULL(a.opening_balance, 0) > 100000
                THEN 50
            WHEN IFNULL(t1.total_trans, 0) = 0
                THEN 30
            WHEN IFNULL(t1.total_withdrawals, 0) > IFNULL(t1.total_deposits, 0)
                THEN 10
            WHEN a.open_date IS NOT NULL
             AND DATEDIFF(a.open_date, c.registration_date) > 180
                THEN 10
            ELSE 0
        END AS suspicion_score

    FROM Customers c
    LEFT JOIN Accounts a ON c.customer_id = a.customer_id
    LEFT JOIN trans_totals t1 ON a.account_id  = t1.account_id
)

SELECT
    ap.customer_id,
    ap.customer_name,
    ap.city,
    ap.segment,
    ap.account_id,
    ap.account_type,
    ap.opening_balance,
    ap.open_date,
    ap.total_trans,
    ap.total_deposits,
    ap.total_withdrawals,
    ap.net_flow,
    ap.days_to_open,
    ap.suspicion_score,

    -- Subquery: find how many other accounts share same type and similar balance
    (
        SELECT COUNT(*)
        FROM Accounts a2
        WHERE a2.account_type = ap.account_type
          AND ABS(a2.opening_balance - ap.opening_balance) <= 5000
          AND a2.account_id  != ap.account_id
    ) AS similar_accounts_count,

    -- Account Flag reads suspicion_score directly
    CASE
        WHEN ap.account_id      = 'No Account' THEN 'no account linked'
        WHEN ap.suspicion_score >= 50 THEN 'multiple red flags detected'
        WHEN ap.suspicion_score >= 30 THEN 'suspicious activity found'
        WHEN ap.suspicion_score >= 10 THEN 'minor irregularity detected'
        ELSE 'no issues found'
    END AS account_flag

FROM account_profile ap
ORDER BY ap.suspicion_score DESC;

                                                                  -- Case Study 2 --
WITH customer_trans AS (
    SELECT
        a.customer_id,
        COUNT(t.transaction_id)AS total_trans,
        SUM(CASE WHEN t.transaction_type = 'Deposit'    THEN t.amount ELSE 0 END) AS total_deposits,
        SUM(CASE WHEN t.transaction_type = 'Withdrawal' THEN t.amount ELSE 0 END) AS total_withdrawals,
        MAX(t.transaction_date) AS last_trans_date
    FROM Accounts a
    LEFT JOIN Transactions t ON a.account_id = t.account_id
    GROUP BY a.customer_id
),

-- CTE 2: Build full customer profile using JOINs
customer_profile AS (
    SELECT
        c.customer_id,
        c.customer_name,
        c.city,
        c.segment,
        c.registration_date,

        -- Subquery: count how many accounts this customer holds
        (
            SELECT COUNT(*)
            FROM Accounts a2
            WHERE a2.customer_id = c.customer_id
        )   AS total_accounts,

        IFNULL(ct.total_trans,0)AS total_trans,
        IFNULL(ct.total_deposits,0)AS total_deposits,
        IFNULL(ct.total_withdrawals,0)AS total_withdrawals,
        IFNULL(ct.total_deposits,0) - IFNULL(ct.total_withdrawals, 0)AS net_flow,

        CASE
            WHEN ct.last_trans_date IS NULL THEN 0
            ELSE DATEDIFF('2024-12-31', ct.last_trans_date)
        END AS last_trans,

        -- Subquery: count how many peers in same city and segment
        (
            SELECT COUNT(*)
            FROM Customers c2
            WHERE c2.city = c.city
              AND c2.segment = c.segment
              AND c2.customer_id != c.customer_id
        ) AS peer_count,

        -- Engagement score using nested CASE WHEN
        CASE
            WHEN IFNULL(ct.total_trans, 0) = 0
                THEN 0
            WHEN IFNULL(ct.total_trans, 0) >= 4
             AND IFNULL(ct.total_deposits,    0)
               - IFNULL(ct.total_withdrawals, 0) > 0
             AND ct.last_trans_date IS NOT NULL
             AND DATEDIFF('2024-12-31', ct.last_trans_date) < 90
                THEN 80
            WHEN IFNULL(ct.total_trans, 0) >= 4
             AND IFNULL(ct.total_deposits,    0) - IFNULL(ct.total_withdrawals, 0) > 0
                THEN 60
            WHEN IFNULL(ct.total_trans, 0) >= 2
             AND IFNULL(ct.total_deposits,    0) - IFNULL(ct.total_withdrawals, 0) > 0
                THEN 40
            WHEN IFNULL(ct.total_trans, 0) >= 2
                THEN 20
            WHEN IFNULL(ct.total_trans, 0) = 1
                THEN 10
            ELSE 0
        END AS engagement_score

    FROM Customers c
    LEFT JOIN customer_trans ct ON c.customer_id = ct.customer_id
)

SELECT
    customer_id,
    customer_name,
    city,
    segment,
    registration_date,
    total_accounts,
    total_trans,
    total_deposits,
    total_withdrawals,
    net_flow,
    last_trans,
    peer_count,
    engagement_score,

    -- Customer Behavior reads engagement_score directly
    CASE
        WHEN total_accounts = 0 THEN 'no accounts'
        WHEN total_trans     = 0 THEN ' less engagement'
        WHEN engagement_score >= 60 THEN 'high engagement'
        WHEN engagement_score >= 30 THEN 'moderate engagement'
        WHEN engagement_score >= 10 THEN 'low engagement '
        ELSE 'zero engagment'
    END AS customer_behavior

FROM customer_profile
ORDER BY engagement_score DESC;

