-- ============================================================
--   SmartAg Database — Complete SQL Implementation
--   Domain   : Smart Agriculture / Farm Monitoring
--   Tables   : Farm (5) | Crop (8) | SensorLog (200) | ReadingDetail (200)
-- ============================================================

CREATE DATABASE SmartAg;
USE SmartAg;

-- ============================================================
-- SECTION A: DDL — CREATE TABLES
-- ============================================================

CREATE TABLE Farm (
    farm_id      VARCHAR(10)  PRIMARY KEY,
    farm_name    VARCHAR(100) NOT NULL,
    province     VARCHAR(50)  NOT NULL,
    climate_zone VARCHAR(50),
    total_fields INT
);

CREATE TABLE Crop (
    crop_id              VARCHAR(10)  PRIMARY KEY,
    crop_name            VARCHAR(100) NOT NULL,
    crop_season          VARCHAR(20),
    crop_type            VARCHAR(50),
    growth_duration_days INT
);

CREATE TABLE SensorLog (
    log_id       VARCHAR(10)  PRIMARY KEY,
    farm_id      VARCHAR(10)  NOT NULL,
    crop_id      VARCHAR(10)  NOT NULL,
    sensor_type  VARCHAR(50),
    reading_date DATE,
    FOREIGN KEY (farm_id) REFERENCES Farm(farm_id),
    FOREIGN KEY (crop_id) REFERENCES Crop(crop_id)
);

CREATE TABLE ReadingDetail (
    log_id            VARCHAR(10)    PRIMARY KEY,
    reading_value     DECIMAL(12, 2),
    alert_triggered   VARCHAR(3),
    growth_stage      VARCHAR(30),
    water_used_liters DECIMAL(10, 2),
    FOREIGN KEY (log_id) REFERENCES SensorLog(log_id)
);


-- ============================================================
-- SECTION B: DML — INSERT
-- ============================================================

INSERT INTO Farm VALUES
('F001','Green Valley Farm','Punjab','Semi-Arid',2),
('F002','Sunrise Agro Farm','Sindh','Arid',2),
('F003','Blue River Estate','KPK','Humid',2),
('F004','Golden Harvest Co','Balochistan','Semi-Arid',2),
('F005','Punjab AgriTech','Punjab','Semi-Arid',2);

INSERT INTO Crop VALUES
('C001','Wheat','Rabi','Grain',90),
('C002','Rice','Kharif','Grain',100),
('C003','Cotton','Kharif','Fiber',150),
('C004','Sugarcane','Kharif','Cash Crop',270),
('C005','Maize','Kharif','Grain',80),
('C006','Tomato','Rabi','Vegetable',60),
('C007','Potato','Rabi','Vegetable',70),
('C008','Sunflower','Rabi','Oilseed',90);

INSERT INTO SensorLog VALUES
('REC0001','F004','C004','pH Sensor','2024-12-14'),
('REC0002','F003','C005','Temperature Sensor','2024-07-10'),
('REC0003','F002','C003','Wind Speed Sensor','2024-05-10'),
('REC0004','F002','C002','NPK Sensor','2024-03-21'),
('REC0005','F004','C008','Rainfall Sensor','2024-07-26'),
('REC0006','F004','C004','Soil Moisture Sensor','2024-12-09'),
('REC0007','F001','C006','Soil Moisture Sensor','2024-02-17'),
('REC0008','F004','C004','Humidity Sensor','2024-07-25'),
('REC0009','F002','C003','Rainfall Sensor','2024-06-08'),
('REC0010','F004','C004','pH Sensor','2024-08-18'),
('REC0011','F004','C008','Soil Moisture Sensor','2024-06-28'),
('REC0012','F003','C007','Wind Speed Sensor','2024-08-12'),
('REC0013','F004','C008','Rainfall Sensor','2024-04-07'),
('REC0014','F002','C002','pH Sensor','2024-12-17'),
('REC0015','F005','C001','Wind Speed Sensor','2024-02-29'),
('REC0016','F004','C008','Soil Moisture Sensor','2024-04-25'),
('REC0017','F002','C002','Wind Speed Sensor','2024-06-17'),
('REC0018','F002','C002','NPK Sensor','2024-01-22'),
('REC0019','F001','C001','Rainfall Sensor','2024-11-12'),
('REC0020','F004','C008','Rainfall Sensor','2024-10-28'),
('REC0021','F005','C001','Humidity Sensor','2024-12-25'),
('REC0022','F003','C005','Wind Speed Sensor','2024-02-08'),
('REC0023','F001','C006','Temperature Sensor','2024-10-14'),
('REC0024','F001','C001','Wind Speed Sensor','2024-02-22'),
('REC0025','F005','C001','NPK Sensor','2024-05-26'),
('REC0026','F005','C001','Soil Moisture Sensor','2024-08-26'),
('REC0027','F005','C001','Wind Speed Sensor','2024-03-26'),
('REC0028','F003','C007','Light Intensity','2024-09-06'),
('REC0029','F004','C008','Wind Speed Sensor','2024-09-03'),
('REC0030','F003','C007','pH Sensor','2024-11-18'),
('REC0031','F005','C001','NPK Sensor','2024-04-24'),
('REC0032','F004','C008','Wind Speed Sensor','2024-08-14'),
('REC0033','F004','C004','Soil Moisture Sensor','2024-12-20'),
('REC0034','F002','C002','pH Sensor','2024-09-21'),
('REC0035','F002','C003','Rainfall Sensor','2024-05-30'),
('REC0036','F005','C001','pH Sensor','2024-09-09'),
('REC0037','F004','C004','Soil Moisture Sensor','2024-10-27'),
('REC0038','F001','C006','pH Sensor','2024-05-05'),
('REC0039','F003','C005','Temperature Sensor','2024-02-13'),
('REC0040','F005','C002','Soil Moisture Sensor','2024-01-14'),
('REC0041','F003','C007','Wind Speed Sensor','2024-05-01'),
('REC0042','F002','C003','Rainfall Sensor','2024-08-07'),
('REC0043','F003','C007','Light Intensity','2024-10-15'),
('REC0044','F001','C006','Soil Moisture Sensor','2024-04-08'),
('REC0045','F005','C001','Temperature Sensor','2024-03-23'),
('REC0046','F003','C005','Humidity Sensor','2024-11-01'),
('REC0047','F001','C006','Temperature Sensor','2024-12-03'),
('REC0048','F002','C003','Temperature Sensor','2024-07-02'),
('REC0049','F004','C008','pH Sensor','2024-12-25'),
('REC0050','F005','C001','Rainfall Sensor','2024-01-22'),
('REC0051','F003','C005','Light Intensity','2024-02-25'),
('REC0052','F004','C008','Temperature Sensor','2024-12-30'),
('REC0053','F005','C002','Light Intensity','2024-01-28'),
('REC0054','F001','C006','Light Intensity','2024-08-15'),
('REC0055','F003','C007','NPK Sensor','2024-10-03'),
('REC0056','F003','C005','Soil Moisture Sensor','2024-04-03'),
('REC0057','F002','C002','pH Sensor','2024-08-12'),
('REC0058','F003','C007','Light Intensity','2024-05-17'),
('REC0059','F003','C007','Wind Speed Sensor','2024-05-16'),
('REC0060','F005','C001','NPK Sensor','2024-05-11'),
('REC0061','F001','C001','Light Intensity','2024-11-04'),
('REC0062','F004','C004','Humidity Sensor','2024-06-05'),
('REC0063','F002','C003','Rainfall Sensor','2024-08-03'),
('REC0064','F002','C003','Temperature Sensor','2024-10-25'),
('REC0065','F004','C008','pH Sensor','2024-06-19'),
('REC0066','F004','C004','Soil Moisture Sensor','2024-10-28'),
('REC0067','F003','C007','Soil Moisture Sensor','2024-07-20'),
('REC0068','F002','C002','NPK Sensor','2024-05-31'),
('REC0069','F001','C001','pH Sensor','2024-12-26'),
('REC0070','F001','C001','Rainfall Sensor','2024-10-12'),
('REC0071','F004','C004','Light Intensity','2024-05-10'),
('REC0072','F002','C002','Wind Speed Sensor','2024-09-11'),
('REC0073','F002','C003','Rainfall Sensor','2024-06-30'),
('REC0074','F003','C007','pH Sensor','2024-01-11'),
('REC0075','F005','C001','NPK Sensor','2024-12-29'),
('REC0076','F005','C002','Light Intensity','2024-07-19'),
('REC0077','F001','C006','Soil Moisture Sensor','2024-06-13'),
('REC0078','F005','C001','Rainfall Sensor','2024-07-08'),
('REC0079','F004','C004','Wind Speed Sensor','2024-08-14'),
('REC0080','F005','C001','Temperature Sensor','2024-03-13'),
('REC0081','F001','C001','Rainfall Sensor','2024-01-17'),
('REC0082','F003','C005','Wind Speed Sensor','2024-01-25'),
('REC0083','F002','C002','Wind Speed Sensor','2024-11-23'),
('REC0084','F001','C006','Humidity Sensor','2024-10-19'),
('REC0085','F001','C006','Light Intensity','2024-08-14'),
('REC0086','F001','C001','Rainfall Sensor','2024-11-13'),
('REC0087','F002','C002','Rainfall Sensor','2024-05-21'),
('REC0088','F002','C003','pH Sensor','2024-07-05'),
('REC0089','F004','C008','pH Sensor','2024-12-14'),
('REC0090','F001','C001','Rainfall Sensor','2024-06-26'),
('REC0091','F005','C002','Humidity Sensor','2024-08-13'),
('REC0092','F003','C007','Rainfall Sensor','2024-03-21'),
('REC0093','F003','C005','Wind Speed Sensor','2024-05-26'),
('REC0094','F005','C001','Soil Moisture Sensor','2024-01-31'),
('REC0095','F001','C001','Soil Moisture Sensor','2024-01-17'),
('REC0096','F003','C007','Rainfall Sensor','2024-10-04'),
('REC0097','F004','C004','Rainfall Sensor','2024-02-02'),
('REC0098','F005','C002','Light Intensity','2024-09-27'),
('REC0099','F003','C007','Light Intensity','2024-12-22'),
('REC0100','F001','C006','Light Intensity','2024-07-26'),
('REC0101','F003','C007','Wind Speed Sensor','2024-11-11'),
('REC0102','F003','C005','NPK Sensor','2024-04-26'),
('REC0103','F001','C001','pH Sensor','2024-04-11'),
('REC0104','F001','C006','pH Sensor','2024-12-18'),
('REC0105','F003','C005','Soil Moisture Sensor','2024-09-18'),
('REC0106','F002','C003','Wind Speed Sensor','2024-11-09'),
('REC0107','F005','C001','Humidity Sensor','2024-02-24'),
('REC0108','F005','C001','Humidity Sensor','2024-02-04'),
('REC0109','F002','C003','pH Sensor','2024-05-31'),
('REC0110','F005','C001','NPK Sensor','2024-05-04'),
('REC0111','F003','C007','NPK Sensor','2024-02-10'),
('REC0112','F001','C001','Wind Speed Sensor','2024-06-12'),
('REC0113','F005','C002','Wind Speed Sensor','2024-10-10'),
('REC0114','F005','C002','Light Intensity','2024-10-19'),
('REC0115','F005','C002','Light Intensity','2024-08-10'),
('REC0116','F003','C005','Rainfall Sensor','2024-03-26'),
('REC0117','F001','C001','Soil Moisture Sensor','2024-05-26'),
('REC0118','F005','C002','Humidity Sensor','2024-11-19'),
('REC0119','F003','C005','Light Intensity','2024-03-29'),
('REC0120','F003','C005','Temperature Sensor','2024-09-23'),
('REC0121','F005','C002','pH Sensor','2024-05-12'),
('REC0122','F003','C007','pH Sensor','2024-10-07'),
('REC0123','F002','C002','Wind Speed Sensor','2024-05-23'),
('REC0124','F004','C004','Light Intensity','2024-11-07'),
('REC0125','F005','C002','Temperature Sensor','2024-01-09'),
('REC0126','F002','C003','pH Sensor','2024-06-15'),
('REC0127','F003','C007','Light Intensity','2024-06-08'),
('REC0128','F004','C004','Soil Moisture Sensor','2024-08-28'),
('REC0129','F003','C005','Soil Moisture Sensor','2024-07-14'),
('REC0130','F003','C005','NPK Sensor','2024-05-09'),
('REC0131','F005','C002','Light Intensity','2024-07-26'),
('REC0132','F003','C007','pH Sensor','2024-12-25'),
('REC0133','F002','C003','Soil Moisture Sensor','2024-05-30'),
('REC0134','F004','C004','NPK Sensor','2024-05-22'),
('REC0135','F002','C003','NPK Sensor','2024-03-13'),
('REC0136','F003','C005','Soil Moisture Sensor','2024-06-12'),
('REC0137','F002','C003','Temperature Sensor','2024-11-11'),
('REC0138','F005','C002','Light Intensity','2024-03-23'),
('REC0139','F004','C004','Temperature Sensor','2024-03-03'),
('REC0140','F001','C006','NPK Sensor','2024-08-06'),
('REC0141','F002','C003','Soil Moisture Sensor','2024-07-06'),
('REC0142','F001','C001','Soil Moisture Sensor','2024-07-10'),
('REC0143','F001','C006','Wind Speed Sensor','2024-08-01'),
('REC0144','F001','C001','Rainfall Sensor','2024-05-31'),
('REC0145','F005','C001','Rainfall Sensor','2024-09-17'),
('REC0146','F002','C003','NPK Sensor','2024-04-14'),
('REC0147','F001','C006','Humidity Sensor','2024-01-10'),
('REC0148','F003','C007','pH Sensor','2024-10-14'),
('REC0149','F003','C007','Rainfall Sensor','2024-05-28'),
('REC0150','F003','C007','Light Intensity','2024-10-09'),
('REC0151','F004','C004','pH Sensor','2024-10-07'),
('REC0152','F005','C001','Temperature Sensor','2024-01-10'),
('REC0153','F001','C001','NPK Sensor','2024-01-14'),
('REC0154','F005','C001','Wind Speed Sensor','2024-08-14'),
('REC0155','F002','C002','Wind Speed Sensor','2024-08-16'),
('REC0156','F002','C002','NPK Sensor','2024-05-31'),
('REC0157','F002','C003','Soil Moisture Sensor','2024-09-07'),
('REC0158','F005','C001','Wind Speed Sensor','2024-11-20'),
('REC0159','F005','C001','Humidity Sensor','2024-03-09'),
('REC0160','F005','C002','NPK Sensor','2024-06-22'),
('REC0161','F005','C001','Wind Speed Sensor','2024-06-30'),
('REC0162','F003','C005','Light Intensity','2024-06-08'),
('REC0163','F002','C002','Light Intensity','2024-08-05'),
('REC0164','F003','C005','Light Intensity','2024-10-15'),
('REC0165','F003','C007','Temperature Sensor','2024-01-22'),
('REC0166','F002','C002','Wind Speed Sensor','2024-08-30'),
('REC0167','F005','C001','pH Sensor','2024-01-26'),
('REC0168','F001','C006','Humidity Sensor','2024-07-15'),
('REC0169','F002','C003','NPK Sensor','2024-09-24'),
('REC0170','F003','C005','NPK Sensor','2024-09-02'),
('REC0171','F004','C004','Wind Speed Sensor','2024-10-09'),
('REC0172','F003','C005','Humidity Sensor','2024-02-29'),
('REC0173','F003','C007','pH Sensor','2024-09-04'),
('REC0174','F002','C002','Soil Moisture Sensor','2024-07-30'),
('REC0175','F003','C005','Light Intensity','2024-07-09'),
('REC0176','F004','C004','Humidity Sensor','2024-03-31'),
('REC0177','F003','C005','Wind Speed Sensor','2024-03-23'),
('REC0178','F002','C003','NPK Sensor','2024-04-29'),
('REC0179','F002','C003','pH Sensor','2024-09-20'),
('REC0180','F001','C006','Rainfall Sensor','2024-09-11'),
('REC0181','F004','C008','Wind Speed Sensor','2024-03-05'),
('REC0182','F005','C002','Rainfall Sensor','2024-06-27'),
('REC0183','F001','C001','Wind Speed Sensor','2024-03-27'),
('REC0184','F002','C003','Wind Speed Sensor','2024-06-25'),
('REC0185','F005','C001','Humidity Sensor','2024-11-05'),
('REC0186','F002','C002','Humidity Sensor','2024-11-28'),
('REC0187','F005','C001','Rainfall Sensor','2024-01-08'),
('REC0188','F002','C002','Light Intensity','2024-03-24'),
('REC0189','F005','C002','Soil Moisture Sensor','2024-02-08'),
('REC0190','F002','C002','Humidity Sensor','2024-11-16'),
('REC0191','F001','C006','pH Sensor','2024-04-08'),
('REC0192','F004','C004','Wind Speed Sensor','2024-03-15'),
('REC0193','F003','C007','Wind Speed Sensor','2024-11-16'),
('REC0194','F003','C007','Wind Speed Sensor','2024-06-24'),
('REC0195','F003','C005','Humidity Sensor','2024-08-21'),
('REC0196','F002','C003','Soil Moisture Sensor','2024-04-18'),
('REC0197','F002','C002','Temperature Sensor','2024-12-06'),
('REC0198','F001','C006','Wind Speed Sensor','2024-08-01'),
('REC0199','F003','C005','Rainfall Sensor','2024-02-16'),
('REC0200','F005','C001','Wind Speed Sensor','2024-04-17');

INSERT INTO ReadingDetail VALUES
('REC0001',6.38,'No','Vegetative',0),
('REC0002',20.40,'No','Flowering',0),
('REC0003',52.54,'No','Maturity',2855.5),
('REC0004',166.89,'No','Maturity',0),
('REC0005',108.01,'No','Vegetative',0),
('REC0006',11.06,'No','Vegetative',2278.4),
('REC0007',59.94,'No','Maturity',0),
('REC0008',NULL,'No','Fruiting',578.6),
('REC0009',152.07,'No','Germination',0),
('REC0010',5.85,'No','Maturity',0),
('REC0011',28.52,'No','Germination',0),
('REC0012',59.78,'No','Vegetative',0),
('REC0013',33.54,'No','Germination',0),
('REC0014',5.75,'No','Flowering',0),
('REC0015',98.89,'No','Fruiting',0),
('REC0016',77.39,'No','Vegetative',0),
('REC0017',NULL,'No','Fruiting',0),
('REC0018',197.41,'No','Vegetative',0),
('REC0019',135.28,'No','Flowering',2986.4),
('REC0020',147.95,'No','Vegetative',1462.7),
('REC0021',60.34,'No','Germination',0),
('REC0022',35.06,'No','Flowering',0),
('REC0023',3.21,'No','Maturity',0),
('REC0024',19.68,'No','Flowering',1828.4),
('REC0025',214.61,'No','Fruiting',563.4),
('REC0026',63.59,'No','Fruiting',0),
('REC0027',138.00,'Yes','Maturity',2638.7),
('REC0028',13397.80,'No','Flowering',0),
('REC0029',69.28,'No','Fruiting',0),
('REC0030',5.15,'No','Fruiting',1036.5),
('REC0031',311.28,'No','Vegetative',0),
('REC0032',45.48,'No','Flowering',0),
('REC0033',47.89,'No','Vegetative',0),
('REC0034',7.49,'No','Fruiting',0),
('REC0035',159.64,'No','Germination',0),
('REC0036',5.20,'No','Maturity',0),
('REC0037',16.26,'No','Germination',0),
('REC0038',7.09,'No','Germination',0),
('REC0039',11.00,'No','Flowering',2811.6),
('REC0040',62.27,'No','Germination',0),
('REC0041',32.65,'No','Fruiting',1400.9),
('REC0042',31.43,'No','Flowering',0),
('REC0043',83896.45,'No','Germination',0),
('REC0044',115.00,'Yes','Fruiting',0),
('REC0045',2.01,'No','Maturity',0),
('REC0046',52.07,'No','Maturity',0),
('REC0047',29.78,'No','Fruiting',0),
('REC0048',-0.92,'No','Vegetative',2052.0),
('REC0049',7.25,'No','Germination',0),
('REC0050',89.12,'No','Vegetative',1410.7),
('REC0051',115000.00,'Yes','Fruiting',2515.5),
('REC0052',29.17,'No','Germination',0),
('REC0053',25858.60,'No','Vegetative',799.4),
('REC0054',65907.96,'No','Maturity',0),
('REC0055',110.26,'No','Maturity',1212.7),
('REC0056',79.70,'No','Germination',0),
('REC0057',6.73,'No','Vegetative',0),
('REC0058',70740.58,'No','Maturity',2203.8),
('REC0059',95.38,'No','Maturity',0),
('REC0060',356.22,'No','Flowering',0),
('REC0061',18767.35,'No','Flowering',0),
('REC0062',28.64,'No','Flowering',0),
('REC0063',100.98,'No','Flowering',0),
('REC0064',38.24,'No','Maturity',0),
('REC0065',6.69,'No','Maturity',0),
('REC0066',23.97,'No','Germination',0),
('REC0067',NULL,'No','Maturity',1495.4),
('REC0068',393.07,'No','Flowering',0),
('REC0069',4.77,'No','Germination',0),
('REC0070',64.11,'No','Germination',0),
('REC0071',49493.38,'No','Flowering',0),
('REC0072',63.25,'No','Flowering',0),
('REC0073',154.45,'No','Vegetative',713.8),
('REC0074',4.61,'No','Germination',0),
('REC0075',232.79,'No','Germination',0),
('REC0076',83830.16,'No','Germination',0),
('REC0077',17.99,'No','Fruiting',1159.2),
('REC0078',130.71,'No','Germination',2007.9),
('REC0079',97.87,'No','Maturity',1709.4),
('REC0080',19.04,'No','Maturity',0),
('REC0081',47.77,'No','Germination',0),
('REC0082',74.39,'No','Vegetative',2174.8),
('REC0083',54.68,'No','Vegetative',0),
('REC0084',40.34,'No','Maturity',0),
('REC0085',NULL,'No','Fruiting',0),
('REC0086',151.05,'No','Flowering',0),
('REC0087',127.33,'No','Flowering',0),
('REC0088',5.82,'No','Vegetative',0),
('REC0089',4.88,'No','Maturity',1460.2),
('REC0090',142.37,'No','Maturity',1059.5),
('REC0091',59.14,'No','Vegetative',0),
('REC0092',97.41,'No','Germination',0),
('REC0093',26.16,'No','Maturity',1335.0),
('REC0094',35.13,'No','Vegetative',0),
('REC0095',10.68,'No','Germination',0),
('REC0096',30.18,'No','Maturity',2270.4),
('REC0097',135.56,'No','Germination',0),
('REC0098',26557.72,'No','Fruiting',2201.2),
('REC0099',43172.41,'No','Germination',1301.9),
('REC0100',75146.74,'No','Flowering',0),
('REC0101',55.34,'No','Flowering',813.0),
('REC0102',419.13,'No','Flowering',1661.5),
('REC0103',6.86,'No','Germination',757.0),
('REC0104',5.60,'No','Maturity',696.4),
('REC0105',32.41,'No','Vegetative',0),
('REC0106',15.67,'No','Germination',1596.5),
('REC0107',75.39,'No','Fruiting',0),
('REC0108',44.70,'No','Vegetative',0),
('REC0109',6.35,'No','Germination',1488.8),
('REC0110',286.84,'No','Vegetative',0),
('REC0111',272.34,'No','Flowering',0),
('REC0112',33.24,'No','Maturity',924.4),
('REC0113',60.02,'No','Maturity',0),
('REC0114',NULL,'No','Maturity',1630.5),
('REC0115',35699.01,'No','Vegetative',0),
('REC0116',166.79,'No','Germination',0),
('REC0117',58.84,'No','Fruiting',2144.6),
('REC0118',60.07,'No','Vegetative',0),
('REC0119',55737.39,'No','Germination',0),
('REC0120',24.81,'No','Vegetative',0),
('REC0121',6.18,'No','Vegetative',0),
('REC0122',5.12,'No','Germination',0),
('REC0123',47.99,'No','Flowering',0),
('REC0124',78831.44,'No','Germination',0),
('REC0125',12.78,'No','Germination',0),
('REC0126',6.47,'No','Germination',0),
('REC0127',57401.16,'No','Vegetative',854.4),
('REC0128',71.40,'No','Maturity',0),
('REC0129',60.22,'No','Flowering',2100.4),
('REC0130',259.17,'No','Fruiting',0),
('REC0131',66712.25,'No','Germination',2162.3),
('REC0132',6.62,'No','Germination',1142.6),
('REC0133',16.57,'No','Germination',0),
('REC0134',128.19,'No','Flowering',0),
('REC0135',NULL,'No','Flowering',1059.0),
('REC0136',67.36,'No','Germination',1756.4),
('REC0137',24.81,'No','Germination',0),
('REC0138',68702.20,'No','Maturity',944.4),
('REC0139',26.41,'No','Vegetative',0),
('REC0140',268.31,'No','Fruiting',0),
('REC0141',17.36,'No','Vegetative',0),
('REC0142',61.61,'No','Germination',0),
('REC0143',18.00,'No','Flowering',0),
('REC0144',78.14,'No','Fruiting',0),
('REC0145',230.00,'Yes','Maturity',0),
('REC0146',65.73,'No','Fruiting',0),
('REC0147',26.85,'No','Germination',0),
('REC0148',NULL,'No','Germination',0),
('REC0149',136.47,'No','Germination',0),
('REC0150',21300.71,'No','Germination',1533.5),
('REC0151',6.26,'No','Germination',0),
('REC0152',4.74,'No','Germination',0),
('REC0153',172.60,'No','Germination',1264.0),
('REC0154',74.61,'No','Flowering',2049.0),
('REC0155',62.46,'No','Vegetative',0),
('REC0156',315.38,'No','Flowering',0),
('REC0157',32.46,'No','Fruiting',2093.9),
('REC0158',14.36,'No','Fruiting',2579.2),
('REC0159',44.36,'No','Fruiting',0),
('REC0160',395.98,'No','Fruiting',0),
('REC0161',17.88,'No','Germination',0),
('REC0162',52012.61,'No','Germination',0),
('REC0163',33152.41,'No','Germination',0),
('REC0164',74510.48,'No','Fruiting',0),
('REC0165',17.50,'No','Vegetative',0),
('REC0166',26.82,'No','Flowering',2391.9),
('REC0167',10.35,'Yes','Vegetative',0),
('REC0168',49.25,'No','Vegetative',2482.1),
('REC0169',186.16,'No','Fruiting',0),
('REC0170',327.40,'No','Germination',2971.0),
('REC0171',14.64,'No','Germination',0),
('REC0172',71.62,'No','Fruiting',0),
('REC0173',7.35,'No','Flowering',0),
('REC0174',61.47,'No','Germination',937.2),
('REC0175',40622.98,'No','Vegetative',0),
('REC0176',27.00,'No','Vegetative',0),
('REC0177',74.94,'No','Germination',0),
('REC0178',86.20,'No','Maturity',531.0),
('REC0179',5.57,'No','Fruiting',0),
('REC0180',53.03,'No','Vegetative',0),
('REC0181',19.40,'No','Fruiting',0),
('REC0182',35.63,'No','Fruiting',0),
('REC0183',12.26,'No','Maturity',2010.2),
('REC0184',16.45,'No','Germination',0),
('REC0185',31.34,'No','Flowering',0),
('REC0186',41.64,'No','Vegetative',0),
('REC0187',144.44,'No','Germination',2679.0),
('REC0188',34081.08,'No','Maturity',0),
('REC0189',65.57,'No','Vegetative',0),
('REC0190',78.26,'No','Vegetative',0),
('REC0191',7.21,'No','Fruiting',0),
('REC0192',66.10,'No','Vegetative',0),
('REC0193',14.29,'No','Flowering',0),
('REC0194',52.86,'No','Flowering',0),
('REC0195',21.03,'No','Maturity',0),
('REC0196',21.56,'No','Fruiting',0),
('REC0197',34.63,'No','Flowering',0),
('REC0198',77.77,'No','Flowering',2631.4),
('REC0199',138.58,'No','Flowering',2485.5),
('REC0200',64.99,'No','Vegetative',0);


-- ============================================================
-- SECTION C: DML — UPDATE & DELETE
-- ============================================================

-- UPDATE: correct a known wrong alert flag
UPDATE ReadingDetail
SET    alert_triggered = 'Yes'
WHERE  log_id = 'REC0044'
  AND  reading_value > 100;

-- UPDATE: fill a default for NULL reading values
UPDATE ReadingDetail
SET    reading_value = 0
WHERE  reading_value IS NULL;

-- DELETE: remove invalid records where reading value is negative
DELETE FROM ReadingDetail WHERE reading_value < 0;


-- ============================================================
-- SECTION D: DQL — 10 ANALYTICAL QUERIES
-- ============================================================

-- ─────────────────────────────────────────────────────────────
-- Q1. Total sensor readings per farm
--     Concepts: INNER JOIN, COUNT, GROUP BY, ORDER BY
--     Question: How many sensor readings has each farm recorded?
-- ─────────────────────────────────────────────────────────────
SELECT
    f.farm_id,
    f.farm_name                   AS farm,
    COUNT(s.log_id)               AS total_readings
FROM Farm        f
INNER JOIN SensorLog s ON f.farm_id = s.farm_id
GROUP BY f.farm_id, f.farm_name
ORDER BY total_readings DESC;

/*
OUTPUT:
farm_id | farm                | total_readings
--------|---------------------|---------------
F003    | Blue River Estate   | 49
F002    | Sunrise Agro Farm   | 43
F005    | Punjab AgriTech     | 43
F001    | Green Valley Farm   | 34
F004    | Golden Harvest Co   | 31
(5 rows)

EXPLANATION:
INNER JOIN connects Farm to SensorLog on farm_id, returning only farms
that have at least one sensor log. COUNT(s.log_id) tallies the log rows
per farm after grouping. Blue River Estate leads with 49 readings,
showing it is the most actively monitored farm in the dataset.
*/


-- ─────────────────────────────────────────────────────────────
-- Q2. Farms with more than 35 sensor logs
--     Concepts: JOIN, GROUP BY, HAVING, ORDER BY
--     Question: Which farms are high-activity monitoring sites?
-- ─────────────────────────────────────────────────────────────
SELECT
    f.farm_name       AS farm,
    f.province,
    COUNT(s.log_id)   AS log_count
FROM Farm        f
JOIN SensorLog   s ON f.farm_id = s.farm_id
GROUP BY f.farm_name, f.province
HAVING COUNT(s.log_id) > 35
ORDER BY log_count DESC;

/*
OUTPUT:
farm               | province | log_count
-------------------|----------|----------
Blue River Estate  | KPK      | 49
Punjab AgriTech    | Punjab   | 43
Sunrise Agro Farm  | Sindh    | 43
(3 rows)

EXPLANATION:
HAVING filters after aggregation, keeping only farms whose total log
count exceeds 35. This is impossible with WHERE alone because WHERE
runs before GROUP BY and the count does not yet exist at that point.
Three farms qualify, all from different provinces, indicating broad
geographic coverage of high-intensity monitoring.
*/


-- ─────────────────────────────────────────────────────────────
-- Q3. Average, min and max reading value per sensor type
--     Concepts: AVG, MIN, MAX, ROUND, GROUP BY, WHERE IS NOT NULL
--     Question: What is the typical reading range for each sensor?
-- ─────────────────────────────────────────────────────────────
SELECT
    s.sensor_type,
    ROUND(AVG(r.reading_value), 2)  AS avg_reading,
    ROUND(MIN(r.reading_value), 2)  AS min_reading,
    ROUND(MAX(r.reading_value), 2)  AS max_reading,
    COUNT(*)                        AS total_logs
FROM SensorLog     s
JOIN ReadingDetail r ON s.log_id = r.log_id
WHERE r.reading_value IS NOT NULL
GROUP BY s.sensor_type
ORDER BY avg_reading DESC;

/*
OUTPUT:
sensor_type          | avg_reading | min_reading | max_reading | total_logs
---------------------|-------------|-------------|-------------|------------
Light Intensity      | 53772.20    | 13397.80    | 115000.00   | 24
NPK Sensor           | 246.00      | 65.73       | 419.13      | 21
Rainfall Sensor      | 111.93      | 30.18       | 230.00      | 27
Wind Speed Sensor    | 50.09       | 12.26       | 138.00      | 36
Humidity Sensor      | 47.77       | 21.03       | 78.26       | 17
Soil Moisture Sensor | 46.78       | 10.68       | 115.00      | 26
Temperature Sensor   | 18.60       | -0.92       | 38.24       | 16
pH Sensor            | 6.29        | 4.61        | 10.35       | 26
(8 rows)

EXPLANATION:
Light Intensity has an extremely high average (53,772) because it
measures lux values which are naturally in the tens of thousands.
Temperature Sensor shows a minimum of -0.92 which is an anomaly worth
investigating. pH Sensor values cluster tightly between 4.61 and 10.35,
consistent with normal soil pH ranges.
*/


-- ─────────────────────────────────────────────────────────────
-- Q4. Readings above the overall dataset average
--     Concepts: Single-row subquery, 4-table JOIN, ORDER BY, LIMIT
--     Question: Which individual readings are above the dataset average?
-- ─────────────────────────────────────────────────────────────
SELECT
    s.log_id,
    f.farm_name          AS farm,
    c.crop_name          AS crop,
    s.sensor_type,
    r.reading_value,
    r.growth_stage
FROM SensorLog     s
JOIN Farm          f ON s.farm_id = f.farm_id
JOIN Crop          c ON s.crop_id = c.crop_id
JOIN ReadingDetail r ON s.log_id  = r.log_id
WHERE r.reading_value > (
    SELECT AVG(reading_value)
    FROM   ReadingDetail
    WHERE  reading_value IS NOT NULL
)
ORDER BY r.reading_value DESC
LIMIT 15;

/*
OUTPUT:
log_id  | farm               | crop     | sensor_type     | reading_value | growth_stage
--------|--------------------|----------|-----------------|---------------|-------------
REC0051 | Blue River Estate  | Maize    | Light Intensity | 115000.00     | Fruiting
REC0043 | Blue River Estate  | Potato   | Light Intensity | 83896.45      | Germination
REC0076 | Punjab AgriTech    | Rice     | Light Intensity | 83830.16      | Germination
REC0124 | Golden Harvest Co  | Sugarcane| Light Intensity | 78831.44      | Germination
REC0100 | Green Valley Farm  | Tomato   | Light Intensity | 75146.74      | Flowering
REC0164 | Blue River Estate  | Maize    | Light Intensity | 74510.48      | Fruiting
REC0058 | Blue River Estate  | Potato   | Light Intensity | 70740.58      | Maturity
REC0138 | Punjab AgriTech    | Rice     | Light Intensity | 68702.20      | Maturity
REC0131 | Punjab AgriTech    | Rice     | Light Intensity | 66712.25      | Germination
REC0054 | Green Valley Farm  | Tomato   | Light Intensity | 65907.96      | Maturity
REC0127 | Blue River Estate  | Potato   | Light Intensity | 57401.16      | Vegetative
REC0119 | Blue River Estate  | Maize    | Light Intensity | 55737.39      | Germination
REC0162 | Blue River Estate  | Maize    | Light Intensity | 52012.61      | Germination
REC0071 | Golden Harvest Co  | Sugarcane| Light Intensity | 49493.38      | Flowering
REC0099 | Blue River Estate  | Potato   | Light Intensity | 43172.41      | Germination
(15 rows)

EXPLANATION:
The subquery returns a single value — the dataset-wide average. All 15
results are Light Intensity readings, confirming that sensor type
dominates the high-value range. This reveals that Light Intensity lux
values are on a completely different numerical scale than all other
sensors, which is important context for any analysis.
*/


-- ─────────────────────────────────────────────────────────────
-- Q5. All sensor activity for Punjab farms
--     Concepts: Multi-row subquery (IN), JOIN, ORDER BY
--     Question: What sensors are active across all Punjab farms?
-- ─────────────────────────────────────────────────────────────
SELECT
    s.log_id,
    s.farm_id,
    s.sensor_type,
    s.reading_date,
    r.reading_value,
    r.alert_triggered
FROM SensorLog     s
JOIN ReadingDetail r ON s.log_id = r.log_id
WHERE s.farm_id IN (
    SELECT farm_id
    FROM   Farm
    WHERE  province = 'Punjab'
)
ORDER BY s.reading_date
LIMIT 20;

/*
OUTPUT (first 20 of 77 rows):
log_id  | farm_id | sensor_type          | reading_date | reading_value | alert_triggered
--------|---------|----------------------|--------------|---------------|----------------
REC0187 | F005    | Rainfall Sensor      | 2024-01-08   | 144.44        | No
REC0125 | F005    | Temperature Sensor   | 2024-01-09   | 12.78         | No
REC0147 | F001    | Humidity Sensor      | 2024-01-10   | 26.85         | No
REC0152 | F005    | Temperature Sensor   | 2024-01-10   | 4.74          | No
REC0040 | F005    | Soil Moisture Sensor | 2024-01-14   | 62.27         | No
REC0153 | F001    | NPK Sensor           | 2024-01-14   | 172.60        | No
REC0081 | F001    | Rainfall Sensor      | 2024-01-17   | 47.77         | No
REC0095 | F001    | Soil Moisture Sensor | 2024-01-17   | 10.68         | No
REC0050 | F005    | Rainfall Sensor      | 2024-01-22   | 89.12         | No
REC0167 | F005    | pH Sensor            | 2024-01-26   | 10.35         | Yes
... (57 more rows)
(77 total rows)

EXPLANATION:
The subquery returns two farm_ids — F001 and F005 — both in Punjab.
The outer query uses IN to retrieve all SensorLog rows matching either
farm. The single alert in the visible rows (REC0167, pH = 10.35)
indicates a soil alkalinity issue at Punjab AgriTech in January.
*/


-- ─────────────────────────────────────────────────────────────
-- Q6. Readings from Semi-Arid climate zone farms
--     Concepts: Nested subquery (3 levels), ORDER BY, LIMIT
--     Question: What data has been collected from Semi-Arid farms?
-- ─────────────────────────────────────────────────────────────
SELECT
    r.log_id,
    r.reading_value,
    r.growth_stage,
    r.water_used_liters
FROM ReadingDetail r
WHERE r.log_id IN (
    SELECT s.log_id
    FROM   SensorLog s
    WHERE  s.farm_id IN (
        SELECT f.farm_id
        FROM   Farm f
        WHERE  f.climate_zone = 'Semi-Arid'
    )
)
ORDER BY r.water_used_liters DESC
LIMIT 20;

/*
OUTPUT (top 20 by water usage):
log_id  | reading_value | growth_stage | water_used_liters
--------|---------------|--------------|------------------
REC0019 | 135.28        | Flowering    | 2986.40
REC0187 | 144.44        | Germination  | 2679.00
REC0027 | 138.00        | Maturity     | 2638.70
REC0198 | 77.77         | Flowering    | 2631.40
REC0158 | 14.36         | Fruiting     | 2579.20
REC0168 | 49.25         | Vegetative   | 2482.10
REC0006 | 11.06         | Vegetative   | 2278.40
REC0098 | 26557.72      | Fruiting     | 2201.20
REC0131 | 66712.25      | Germination  | 2162.30
REC0117 | 58.84         | Fruiting     | 2144.60
REC0154 | 74.61         | Flowering    | 2049.00
REC0183 | 12.26         | Maturity     | 2010.20
REC0078 | 130.71        | Germination  | 2007.90
REC0024 | 19.68         | Flowering    | 1828.40
REC0079 | 97.87         | Maturity     | 1709.40
REC0114 | NULL          | Maturity     | 1630.50
REC0020 | 147.95        | Vegetative   | 1462.70
REC0089 | 4.88          | Maturity     | 1460.20
REC0050 | 89.12         | Vegetative   | 1410.70
REC0153 | 172.60        | Germination  | 1264.00
(20 of 105 rows)

EXPLANATION:
Three nested subqueries drill from climate_zone → farm_id → log_id →
reading details. Semi-Arid farms (F001, F004, F005) account for 105
records. The high water usage values confirm that Semi-Arid farms
require significantly more irrigation than Humid or Arid zones.
*/


-- ─────────────────────────────────────────────────────────────
-- Q7. Alert-triggered readings with severity classification
--     Concepts: CASE WHEN, WHERE, 4-table JOIN, ORDER BY, LIMIT
--     Question: How severe are the readings that triggered alerts?
-- ─────────────────────────────────────────────────────────────
SELECT
    s.log_id,
    f.farm_name,
    c.crop_name,
    s.sensor_type,
    r.reading_value,
    CASE
        WHEN r.reading_value < 20    THEN 'Low'
        WHEN r.reading_value < 100   THEN 'Moderate'
        WHEN r.reading_value < 500   THEN 'High'
        ELSE                              'Critical'
    END AS risk_level
FROM SensorLog     s
JOIN Farm          f ON s.farm_id = f.farm_id
JOIN Crop          c ON s.crop_id = c.crop_id
JOIN ReadingDetail r ON s.log_id  = r.log_id
WHERE r.alert_triggered = 'Yes'
ORDER BY r.reading_value DESC
LIMIT 10;

/*
OUTPUT:
log_id  | farm_name          | crop_name | sensor_type          | reading_value | risk_level
--------|--------------------|-----------|----------------------|---------------|----------
REC0051 | Blue River Estate  | Maize     | Light Intensity      | 115000.00     | Critical
REC0145 | Punjab AgriTech    | Wheat     | Rainfall Sensor      | 230.00        | High
REC0027 | Punjab AgriTech    | Wheat     | Wind Speed Sensor    | 138.00        | High
REC0044 | Green Valley Farm  | Tomato    | Soil Moisture Sensor | 115.00        | High
REC0167 | Punjab AgriTech    | Wheat     | pH Sensor            | 10.35         | Low
(5 rows)

EXPLANATION:
Only 5 records have alert_triggered = 'Yes' across 200 logs — a 2.5%
alert rate. The Critical alert (REC0051, 115,000 lux) at Blue River
Estate on Maize is a clear sensor anomaly. The Low-risk pH alert
(REC0167, pH 10.35) on Wheat at Punjab AgriTech indicates high soil
alkalinity that could affect nutrient absorption.
*/


-- ─────────────────────────────────────────────────────────────
-- Q8. Farms sharing the same province
--     Concepts: SELF JOIN, alias, ORDER BY
--     Question: Which pairs of farms operate in the same province?
-- ─────────────────────────────────────────────────────────────
SELECT
    a.farm_name    AS farm_a,
    b.farm_name    AS farm_b,
    a.province     AS shared_province,
    a.climate_zone
FROM Farm a
JOIN Farm b
  ON  a.province = b.province
  AND a.farm_id  < b.farm_id
ORDER BY a.province;

/*
OUTPUT:
farm_a             | farm_b          | shared_province | climate_zone
-------------------|-----------------|-----------------|-------------
Green Valley Farm  | Punjab AgriTech | Punjab          | Semi-Arid
(1 row)

EXPLANATION:
The SELF JOIN pairs each farm with every other farm in the same province.
The condition a.farm_id < b.farm_id prevents duplicate pairs and
self-pairing. Only one pair exists — both Punjab farms share Semi-Arid
climate, meaning they face similar agricultural challenges and their
data can be directly compared for benchmarking purposes.
*/


-- ─────────────────────────────────────────────────────────────
-- Q9. Water usage summary per crop
--     Concepts: SUM, AVG, UPPER, CONCAT, ROUND, DATEDIFF, GROUP BY
--     Question: Which crops consume the most irrigation water?
-- ─────────────────────────────────────────────────────────────
SELECT
    UPPER(c.crop_name)                          AS crop_upper,
    CONCAT(c.crop_season, ' - ', c.crop_type)   AS season_type,
    c.growth_duration_days,
    ROUND(SUM(r.water_used_liters), 1)          AS total_water_L,
    ROUND(AVG(r.water_used_liters), 1)          AS avg_water_L,
    COUNT(s.log_id)                             AS log_count,
    MAX(s.reading_date)                         AS last_reading,
    DATEDIFF(CURDATE(), MAX(s.reading_date))    AS days_since_last
FROM Crop          c
JOIN SensorLog     s ON c.crop_id  = s.crop_id
JOIN ReadingDetail r ON s.log_id   = r.log_id
GROUP BY c.crop_id, c.crop_name, c.crop_season, c.crop_type,
         c.growth_duration_days
ORDER BY total_water_L DESC;

/*
OUTPUT:
crop_upper | season_type         | growth_days | total_water_L | avg_water_L | log_count | last_reading
-----------|---------------------|-------------|---------------|-------------|-----------|-------------
WHEAT      | Rabi - Grain        | 90          | 26902.4       | 625.6       | 43        | 2024-12-29
MAIZE      | Kharif - Grain      | 80          | 19811.7       | 825.5       | 24        | 2024-11-01
POTATO     | Rabi - Vegetable    | 70          | 15265.1       | 610.6       | 25        | 2024-12-25
COTTON     | Kharif - Fiber      | 150         | 12390.5       | 538.7       | 23        | 2024-11-11
RICE       | Kharif - Grain      | 100         | 11066.9       | 307.4       | 36        | 2024-12-17
TOMATO     | Rabi - Vegetable    | 60          | 6969.1        | 387.2       | 18        | 2024-12-18
SUGARCANE  | Kharif - Cash Crop  | 270         | 4566.4        | 240.3       | 19        | 2024-12-20
SUNFLOWER  | Rabi - Oilseed      | 90          | 2922.9        | 243.6       | 12        | 2024-12-30
(8 rows)

EXPLANATION:
Wheat has the highest total water consumption (26,902 L) but Maize has
the highest average per log (825.5 L), suggesting Maize requires more
intensive irrigation per session. Sugarcane, despite its 270-day growth
cycle (longest of all crops), ranks near the bottom — indicating either
lower monitoring frequency or natural rainfall sufficiency.
*/


-- ─────────────────────────────────────────────────────────────
-- Q10. Monthly sensor activity trend
--      Concepts: MONTH(), YEAR(), SUM(CASE WHEN), GROUP BY, ORDER BY
--      Question: Which months had highest activity and how did
--                water usage vary month by month?
-- ─────────────────────────────────────────────────────────────
SELECT
    YEAR(s.reading_date)                                          AS yr,
    MONTH(s.reading_date)                                         AS mo,
    COUNT(s.log_id)                                               AS readings_count,
    SUM(CASE WHEN r.alert_triggered = 'Yes' THEN 1 ELSE 0 END)   AS alerts_count,
    ROUND(SUM(r.water_used_liters), 1)                            AS total_water_L,
    ROUND(AVG(r.reading_value), 2)                                AS avg_sensor_val
FROM SensorLog     s
JOIN ReadingDetail r ON s.log_id = r.log_id
GROUP BY YEAR(s.reading_date), MONTH(s.reading_date)
ORDER BY yr, mo;

/*
OUTPUT:
yr   | mo | readings_count | alerts_count | total_water_L | avg_sensor_val
-----|----|----------------|--------------|---------------|---------------
2024 | 1  | 16             | 1            | 8327.9        | 1673.08
2024 | 2  | 13             | 1            | 9641.0        | 8925.26
2024 | 3  | 17             | 1            | 6652.3        | 9961.33
2024 | 4  | 12             | 1            | 2949.5        | 107.38
2024 | 5  | 23             | 0            | 11992.0       | 5349.51
2024 | 6  | 18             | 0            | 6467.7        | 6504.14
2024 | 7  | 16             | 0            | 13815.9       | 19059.00
2024 | 8  | 21             | 0            | 8781.7        | 6792.53
2024 | 9  | 15             | 1            | 7266.1        | 2733.33
2024 | 10 | 18             | 0            | 8109.8        | 11266.76
2024 | 11 | 16             | 0            | 9011.6        | 6145.80
2024 | 12 | 15             | 0            | 6879.5        | 2910.62
(12 rows)

EXPLANATION:
May has the highest reading count (23), aligning with the start of the
Kharif sowing season. July records the highest water usage (13,815 L),
consistent with peak summer irrigation demand. All 5 alerts are
concentrated in January–April and September, suggesting sensor stress
during transitional seasons. MONTH() and YEAR() extract date components
for grouping, while SUM(CASE WHEN) conditionally counts only alert rows
within each monthly group.
*/